<?php
// Template Name: Class Schedule
get_header(); 
?>
<!-- Page Title -->
<section class="Class_Schedule page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');"> 
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                   <?php echo get_field( 'page_title' ); ?>
                </div>
                <div class="regular text-center text-white">         
                    <?php echo get_field( 'page_sub_title' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<!-- Content Here -->
<Section class="cs-section section calendar_wrap">
    <div class="container ">
        <div class="row pb-4">
            <div class="col-md-6">
                <ul class="list_of_studio">
                    <li class="text-white list_all list_studio" onclick="filterContent('all')">
                        <?php echo get_field('list_all'); ?>
                    </li>
                    <li class="text-white list_cc_a list_studio" onclick="filterContent('studio_a')">
                        <?php echo get_field('list_studio_a'); ?>
                    </li>
                    <li class="text-white list_cc_b list_studio" onclick="filterContent('studio_b')">
                        <?php echo get_field('list_studio_b'); ?>
                    </li>
                    <li class="text-white list_cc_c list_studio" onclick="filterContent('studio_c')">
                        <?php echo get_field('list_studio_c'); ?>
                    </li>
                    <li class="text-white list_cc_d list_studio" onclick="filterContent('studio_d')">
                        <?php echo get_field('list_studio_d'); ?>
                    </li>
                    <li class="text-white list_cc_e list_studio" onclick="filterContent('studio_e')">
                        <?php echo get_field('list_studio_e'); ?>
                    </li>
                </ul>
            </div>
            <div class="col-md-6">
                <div class="pdf_btn">
                    <a class="download_pdf register_btn" href=""><?php echo get_field('download_pdf'); ?></a>
                </div>
            </div>
        </div>
        <div class="row">
            <?php if (have_rows('weekly_schedule')) : ?>
                <div class="weekly-schedule">
                    <?php while (have_rows('weekly_schedule')) : the_row(); ?>
                        <div class="day-box">
                            <div class="day">
                                <?php echo get_sub_field('day_title'); ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
            <?php foreach (['studio_a', 'studio_b', 'studio_c', 'studio_d','studio_e'] as $studio) : ?>
                <?php if (have_rows($studio)) : ?>
                    <div class="class-schedule <?php echo $studio; ?> hide">
                        <?php while (have_rows($studio)) : the_row(); ?>
                            <div class="class-card cc_<?php echo substr($studio, -1); ?>">
                                <div class="studio"><?php echo get_sub_field('studio'); ?></div>
                                <div class="text-center">
                                    <!-- <div class="class-name"><?php echo get_sub_field('title'); ?></div> -->
                                    <div class="time"><?php echo get_sub_field('time'); ?></div>
                                </div>
                                <div class="container_card">
                                    <div class="studio-letter">
                                        <?php echo get_sub_field('studio_letter'); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
</Section>

<script>
    function filterContent(studio) {
    // Hide all schedules
    const schedules = document.querySelectorAll('.class-schedule');
    schedules.forEach(schedule => schedule.classList.add('hide'));

    // Show the selected schedule
    if (studio === 'all') {
        schedules.forEach(schedule => schedule.classList.remove('hide'));
    } else {
        document.querySelector('.' + studio).classList.remove('hide');
    }
    }

    // Initial setup to hide all schedules
    document.addEventListener('DOMContentLoaded', () => {
    filterContent('all'); // Show all schedules by default
    });
</script>

<!-- Content Ends -->
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php

get_footer(); 
?>