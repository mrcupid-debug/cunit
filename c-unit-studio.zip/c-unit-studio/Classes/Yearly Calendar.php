<?php
// Template Name: Yearly Calendar
get_header(); 
?>
<!-- Page Title -->
<section class="yearly-calendar page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');"> 
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                    <?php echo get_field( 'page_title' ); ?>
                </div>
                <div class="regular text-center text-white">         
                    <?php echo get_field( 'page_sub_title' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<!-- Content Here -->
<section class="yc_section section">
    <div class="container">
        <div class="row calendar-yearly">
        <?php if ( have_rows( 'yc_content' ) ) : ?>
    <?php 
    $counter = 0; // Initialize a counter to track the column index
    while ( have_rows( 'yc_content' ) ) : the_row(); 
        $counter++; // Increment the counter
        $is_right_column = $counter % 2 == 0; // Check if it's the right column
    ?>
        <div class="col-md-6 <?php echo $is_right_column ? 'right-column' : ''; ?>">
            <div class="wrapper yc_wrapper mb-4 <?php echo $is_right_column ? 'flex-row-reverse' : ''; ?>">
               
                <div class="yc_content <?php echo $is_right_column ? 'text-right' : ''; ?>">
                    <div class="description pb-2">                
                        <?php echo get_sub_field( 'title' ); ?>
                    </div>
                    <div class="yc_section_month">
                        <?php echo get_sub_field( 'month' ); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
<?php endif; ?>

        </div>
    </div>
</section>

<!-- Content Ends -->
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>