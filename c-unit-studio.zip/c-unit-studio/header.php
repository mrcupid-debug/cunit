<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package C_Unit_Studio
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<link rel="icon" type="image/x-icon" href="https://isbeingbuilt.com/cunit/wp-content/uploads/2024/06/favicon-300x300-1.webp">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.3.2/html2canvas.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic|Oswald:400,700" media="screen"> 
	<link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.2/css/fontawesome.min.css" integrity="sha384-BY+fdrpOd3gfeRvTSMT+VUZmA728cfF9Z2G42xpaRkUGu2i3DyzpTURDo5A6CaLK" crossorigin="anonymous">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">	
<header class="header py-3">
	<div class="container">
		<div class="row align_center">
			<div class="col-md-2">
				<div class="header_logo">
					<a href="<?php echo get_field('homepage_link', 'options'); ?>">
						<img src="<?php echo esc_url(get_field('image', 'options')); ?>" alt="C-Unit Studio">
					</a>
				</div>
			</div>
			<div class="col-md-10 nav__men">
					<div class="menu-toggle">
						<div class="mobile_header_logo">
							<a href="<?php echo get_field('homepage_link', 'options'); ?>">
								<img src="<?php echo esc_url(get_field('image', 'options')); ?>" alt="C-Unit Studio">
							</a>
						</div>
						<div class="hamburger" onclick="mainMenu(this)">
							<div class="span1"></div>
							<div class="span2"></div>
							<div class="span3"></div>
						</div> 
					</div>
				<div class="nav_menu">
					<div class="hambuger_header_logo">
						<a href="<?php echo get_field( 'homepage_link', 'options' ); ?>"><img src="<?php echo get_field( 'rco_image', 'options' ); ?>" alt=""></a>
					</div>
					<?php echo wp_nav_menu(array(
						'theme_location' => 'main-menu',
						'fallback_cb' => false,
						'container' => 'nav',
						'container_class' => 'main-menu',
						'menu_class' => 'menu',
					)); ?>
					<a href="<?php echo esc_url(get_field('link', 'options')); ?>" class="register_btn header_register hover_btn"><?php echo get_field('registerlogin', 'options'); ?></a>
				</div>
			</div>
		</div>
	</div>
	<div class="hamburger_sidebar" onclick="sidebarMenu(this)">
		<div class="span1"></div>
		<div class="span2"></div>
		<div class="span3"></div>
	</div> 
		<div class="Overlay_sidebar">
				<div class="box-wrapper">
					<div class="header_logo py-4">
						<a href="<?php echo get_field( 'homepage_link', 'options' ); ?>"><img src="<?php echo get_field( 'rco_image', 'options' ); ?>" alt=""></a>
					</div>
					<div class="header_text py-4">
						<p>	<?php echo get_field( 'rco_text', 'options' ); ?></p>
					</div>
					<div class="header_email py-4">
						<p><strong><?php echo get_field( 'rco_email_label', 'options' ) ; ?></strong></p>
						<a href="mailto:<?php echo get_field( 'rco_email', 'options' ); ?>"><?php echo  get_field( 'rco_email', 'options' ); ?></a>
					</div>
					<div class="header_phone py-4">
						<p><strong><?php echo get_field( 'rco_phone_label', 'options' ); ?></strong></p>
						<?php if ( $number = get_field( 'number', 'options' ) ) : ?>
							<a href=""><?php echo esc_html( $number ); ?></a>
						<?php endif; ?>
					</div>	
					<div class="header_address py-4">
						<p><strong><?php echo get_field( 'rco_address_label', 'options' ); ?></strong></p>
						<a class="" href="<?php echo get_field( 'link_address', 'options' );?>"> <?php echo get_field( 'address', 'options' ) ; ?></a>
					</div>
					<div class="header_socials py-4">
						<?php if ( have_rows( 'social_icon', 'options' ) ) : ?>
						<?php while ( have_rows( 'social_icon', 'options' ) ) :
						the_row(); ?>	
							<div class="social_icons px-2">
								<a href="<?php echo  get_sub_field( 'link', 'options' );?>" target="_blank"><?php echo get_sub_field( 'icon', 'options' ); ?></a>
							</div>
						<?php endwhile; ?>
						<?php endif; ?>
					</div>
					<div class="header_btn  pt-3">				
						<a class="button register_btn hover_btn" href="<?php echo get_field( 'button_link', 'options' );?>" target="<?php echo get_field( 'button_link', 'options' ); ?>"><?php echo get_field( 'text_button', 'options' ); ?></a>
					</div>
				</div>
		</div>
</header>
<div onclick="topFunction()" id="myBtn" title="Go to top"><img src="<?php echo esc_url( get_field( 'back_to_top_icon', 'options' ) ); ?>" alt=""></div>
<?php