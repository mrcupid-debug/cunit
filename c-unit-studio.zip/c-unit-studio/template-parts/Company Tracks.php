<?php
// Template Name: Company Tracks
get_header(); 
?>
<section class="company_tracks page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');"> 
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                    <div class="title page_title"><?php echo get_field( 'company_tracks_title' ); ?></div>
                </div>
                <div class="regular text-center text-white">                   
                    <?php echo get_field( 'company_tracks_sub_title' ) ; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<section class="ct_content section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="ct--image" ><img src="<?php echo get_field( 'the_movement_image' ); ?>" alt=""></div>
            </div>
            <div class="col-md-6 ">
                <div class="ct_bgcolor" style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                    <div class="sub_title title pb-2">
                        <?php echo get_field( 'the_movement_title' ); ?>
                    </div>
                    <div class="regular__ ">
                        <?php echo get_field( 'movement_content' ); ?>
                    </div>
                </div>
            </div>
        </div> 
        <div class="row py-3">
            <div class="col-md-6 ">
                <div class="ct_bgcolor" style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                <div class="sub_title title pb-2">
                        <?php echo get_field( 'g_title' ); ?>
                    </div>
                    <div class="regular__  content_width">      
                        <?php echo  get_field( 'g_content' ); ?>
                    </div>
               </div>
            </div>
            <div class="col-md-6 ">
                <div class="ct_bgcolor" style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                    <div class="sub_title title pb-2">   
                        <?php echo get_field( 'requirements_title' ); ?>
                    </div>
                    <div class="regular__">
                        <?php echo get_field( 'requirements_content' ) ; ?>
                    </div>
               </div>
            </div>
        </div>
        <div class="row py-3">
            <div class="col-md-6 ">
                <div class="ct_bgcolor" style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                    <div class="sub_title title pb-2">
                        <?php echo get_field( 'the_company_title' ); ?>
                    </div>
                    <div class="regular__ ">
                        <?php echo   get_field( 'the_company_content' ); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="ct--image" ><img src="<?php echo get_field( 'the_company_image' );; ?>" alt=""></div>
            </div>
        </div> 
        <div class="row py-3">
            <div class="col-md-6 ">
               <div class="ct_bgcolor"  style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                <div class="sub_title title pb-2">
                        <?php echo get_field( 'the_requirementshours_2_title' ); ?>
                    </div>
                    <div class="regular__">    
                        <?php echo  get_field( 'the_requirementshours_2_content' ); ?>
                    </div>
               </div>
            </div>
            <div class="col-md-6 ">
                <div class="center__ ct_bgcolor"  style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                    <div class="color_wrapper">
                        <a class="ct_wrapper2 register_btn hover_btn" href=" <?php echo get_field( 'url', 'options' ); ?>">                    
                                <?php echo get_field( 'rgtr_button', 'options' ); ?>
                        </a>
                    </div>
               </div>
            </div>
        </div>
    </div>
</section>
 

<!-- flexible content -->
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>