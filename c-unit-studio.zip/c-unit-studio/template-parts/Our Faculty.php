<?php
// Template Name: Our Faculty
get_header(); 
?>
<section class="Our_Faculty page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                    <div class="title"><?php echo get_field( 'our_faculty_title' ); ?></div>
                </div>
                <div class="regular text-center text-white">         
                    <?php echo get_field( 'our_faculty_text' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>  
<section class="ofaculty_section">
    <div class="container-fluid">
        <div class="row">
            <?php if ( have_rows( 'our_faculty_repeater' ) ) : $row_count = 0; ?>
                <?php while ( have_rows( 'our_faculty_repeater' ) ) : the_row(); 
                    $row_count++; 
                    $reverse = $row_count % 2 == 0 ;
                ?>
                    <div class="col-md-6 <?php echo $reverse ? ' of_bgcolor' : ''; ?>" data-aos="fade-right" data-aos-duration="400"
                    data-aos-easing="ease-in-sine">
                        <div class="<?php echo $reverse ? 'of-wrapper' : 'of_img'; ?>">
                            <?php if ( $reverse ) : ?>
                                <div class="of_position aqua regular"><?php echo get_sub_field( 'our_faculty_position' ); ?></div>  
                                <div class="of_name sub_title text-white py-2"><?php echo get_sub_field( 'our_faculty_name' ); ?></div>
                                <div class="of_about regular"><?php echo get_sub_field( 'our_faculty_about' ); ?></div>
                            <?php else : ?>
                                <img src="<?php echo esc_url( get_sub_field( 'our_faculty_image' ) ); ?>" alt="">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6<?php echo !$reverse ? ' of_bgcolor' : ''; ?>" data-aos="fade-left" data-aos-duration="800"
                    data-aos-easing="ease-in-sine">
                        <div class="<?php echo !$reverse ? 'of-wrapper' : 'of_img'; ?>">
                            <?php if ( !$reverse ) : ?>
                                <div class="of_position aqua regular"><?php echo get_sub_field( 'our_faculty_position' ); ?></div>  
                                <div class="of_name sub_title text-white py-2"><?php echo get_sub_field( 'our_faculty_name' ); ?></div>
                                <div class="of_about regular"><?php echo get_sub_field( 'our_faculty_about' ); ?></div>
                            <?php else : ?>
                                <img src="<?php echo esc_url( get_sub_field( 'our_faculty_image' ) ); ?>" alt="">
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
            <?php if ( have_rows( 'of_repeater_text' ) ) :  $row_count = 0; ?>
                <?php while ( have_rows( 'of_repeater_text' ) ) : the_row(); 
                    $row_count++; 
                    $reverse = $row_count % 2 == 0; // Correct the condition to match odd rows ?>
                    <div class="col-md-6<?php echo $reverse ? ' of_bgcolor' : ''; ?>"data-aos="fade-right"
                    data-aos-easing="ease-in-sine" >
                        <div class="<?php echo $reverse ? 'of-wrapper' : 'of_heading'; ?>">
                            <?php if ( $reverse ) : ?>
                                <div class="of_position aqua regular">
                                    <?php echo get_sub_field( 'of_position' ); ?>
                                </div>  
                                <div class="of_name sub_title text-white py-2">
                                    <?php echo get_sub_field( 'of_name' ); ?>
                                </div>
                                <div class="of_about regular">
                                    <?php echo get_sub_field( 'of_about' ); ?>
                                </div>
                            <?php else : ?>
                                <div class="of_heading">
                                    <?php echo get_sub_field( 'of_title_text' ); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6<?php echo !$reverse ? ' of_bgcolor' : ''; ?>"data-aos="fade-left"
                    data-aos-easing="ease-in-sine">
                        <div class="<?php echo !$reverse ? 'of-wrapper' : 'of_heading'; ?>">
                            <?php if ( !$reverse ) : ?>
                                <div class="of_position aqua regular">
                                    <?php echo get_sub_field( 'of_position' ); ?>
                                </div>  
                                <div class="of_name sub_title text-white py-2">
                                    <?php echo get_sub_field( 'of_name' ); ?>
                                </div>
                                <div class="of_about regular">
                                    <?php echo get_sub_field( 'of_about' ); ?>
                                </div>
                            <?php else : ?>
                                <div class="of_heading">
                                    <?php echo get_sub_field( 'of_title_text' ); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>      
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<section class="of_mobile section">
    <div class="container-fluid">
        <div class="row">
        <?php if ( have_rows( 'our_faculty_repeater' ) ) :?>
            <?php while ( have_rows( 'our_faculty_repeater' ) ) : the_row();  ?>
                <div class="col-md-6  " data-aos="fade-right" data-aos-duration="400"
                data-aos-easing="ease-in-sine">
                    <div class=" of_img">
                        <img src="<?php echo esc_url( get_sub_field( 'our_faculty_image' ) ); ?>" alt="">
                    </div>
                </div>
                <div class="col-md-6 of_bgcolor" data-aos="fade-left" data-aos-duration="800"
                data-aos-easing="ease-in-sine">
                    <div class="of-wrapper">
                        <div class="of_position aqua regular"><?php echo get_sub_field( 'our_faculty_position' ); ?></div>  
                        <div class="of_name sub_title text-white py-2"><?php echo get_sub_field( 'our_faculty_name' ); ?></div>
                        <div class="of_about regular"><?php echo get_sub_field( 'our_faculty_about' ); ?></div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
        <?php if ( have_rows( 'of_repeater_text' ) ) :?>
            <?php while ( have_rows( 'of_repeater_text' ) ) : the_row(); ?>
                <div class="col-md-6"data-aos="fade-right"
                data-aos-easing="ease-in-sine" >
                    <div class="of_heading">
                        <div class="of_heading">
                            <?php echo get_sub_field( 'of_title_text' ); ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 of_bgcolor" data-aos="fade-left"
                data-aos-easing="ease-in-sine">
                    <div class="of-wrapper">
                            <div class="of_position aqua regular">
                                <?php echo get_sub_field( 'of_position' ); ?>
                            </div>  
                            <div class="of_name sub_title text-white py-2">
                                <?php echo get_sub_field( 'of_name' ); ?>
                            </div>
                            <div class="of_about regular">
                                <?php echo get_sub_field( 'of_about' ); ?>
                            </div>
                    </div>
                </div>      
            <?php endwhile; ?>
        <?php endif; ?>
        </div>
    </div>
</section>
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>  