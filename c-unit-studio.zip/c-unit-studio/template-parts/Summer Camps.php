<?php
// Template Name: Summer Camp
get_header(); 
?>
<!-- Page Title -->
<section class="summar_camps">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="Title text-white">     
                    <div class="text-center "><?php echo get_field( 'page_title' ); ?></div>
                </div>

                <div class="button_wrapper">
                    <a href="<?php echo get_field( 'register_url' ); ?>" class="register_btn hover_btn summer_camp_btn mx-2">
                        <?php echo get_field( 'register_button' ); ?>
                    </a>
                    <a class="white_bg hover_btn"  data-toggle="modal" data-target="#ModalCenter" href="#"> <?php echo get_field( 'watch_button' ); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_template_part('section/modal'); ?>
<div class="section_image_top"> 
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<!-- Content Here -->
<section class="sc_section section">
    <div class="container">
        <div class="row yc_wrapper">
            <div class="col-md-4 md-5">
               <div class="sc_image">
               <img src="<?php echo esc_url( get_field( 'intensive_image' ) ); ?>" alt="">
               </div>   
            </div>
            <div class="col-md-5 ps-3">
                    <div class="sc_wrapper pt-4">
                        <div class="sub_title">
                            <?php echo  get_field( 'intensive_title' ); ?>
                        </div>
                        <div class="description">
                            <?php echo get_field( 'intensive_sub_title' ); ?>
                        </div>
                    </div>
                    <div class="regular py-3">       
                        <?php echo get_field( 'intensive_content' );?>
                    </div>
            </div>
            <div class="col-md-3 md_2 sc_flex" >
               <ul class="sc_ul_serviceInfo regular text-white">
                <li class="dark_bg_aqua list_studio">
                    <?php echo get_field( 'intensive_service_info_1' ) ; ?>
                </li>
                <li class="bg_aqua list_studio">
                    <?php echo get_field( 'intensive_service_info_2' ) ; ?>
                </li>
                <li class="bg_aqua list_studio">
                    <?php echo get_field( 'intensive_service_info_3' ) ; ?>
                </li>
                <li class="bg_light_aqua list_studio">
                    <a href="<?php echo get_field( 'register_url' ); ?>" class="bg_light_aqua"><?php echo get_field( 'Inner_register_button' ) ; ?></a>
                </li>
               </ul>
            </div>
        </div>

        <div class="row yc_wrapper right_mb my-4" data-aos="fade-left">
            <div class="col-md-3 md_2 sc_flex">
                <ul class="sc_ul_serviceInfo regular text-white">

                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'mms_service_info_1' ) ; ?>
                    </li>
                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'mms_service_info_2' ) ; ?>
                    </li>
                    <li class="bg_aqua list_studio">
                        <?php echo get_field( 'mms_service_info_3' ) ; ?>
                    </li>
                    <li class="bg_light_aqua list_studio">
                        <a href="<?php echo get_field( 'register_url' ); ?>" class="bg_light_aqua"><?php echo get_field( 'Inner_register_button' ) ; ?></a>
                    </li>
                </ul>
            </div>
            <div class="col-md-5 ps-3">
                    <div class="sc_wrapper pt-4">
                        <div class="sub_title">
                            <?php echo  get_field( 'mms_title' ); ?>
                        </div>
                        <div class="description">
                            <?php echo get_field( 'mms_sub_title' ); ?>
                        </div>
                    </div>
                    <div class="regular py-3">       
                        <?php echo get_field( 'mms_content' );?>
                    </div>
            </div>
            <div class="col-md-4 md-5">
               <div class="sc_image">
               <img src="<?php echo esc_url( get_field( 'mms_image' ) ); ?>" alt="">
               </div>   
            </div>
        </div>

        <div class="row yc_wrapper mobile_yc my-4" data-aos="fade-left">
        <div class="col-md-4 md-5">
                <div class="sc_image">
                <img src="<?php echo esc_url( get_field( 'mms_image' ) ); ?>" alt="">
                </div>   
                </div>
           
            <div class="col-md-5 ps-3">
                <div class="sc_wrapper pt-4">
                    <div class="sub_title">
                        <?php echo  get_field( 'mms_title' ); ?>
                    </div>
                    <div class="description">
                        <?php echo get_field( 'mms_sub_title' ); ?>
                    </div>
                </div>
                <div class="regular py-3">       
                    <?php echo get_field( 'mms_content' );?>
                </div>
            </div>
            <div class="col-md-3 md_2 sc_flex">
                <ul class="sc_ul_serviceInfo regular text-white">
                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'mms_service_info_1' ) ; ?>
                    </li>
                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'mms_service_info_2' ) ; ?>
                    </li>
                    <li class="bg_aqua list_studio">
                        <?php echo get_field( 'mms_service_info_3' ) ; ?>
                    </li>
                    <li class="bg_light_aqua list_studio">
                        <a href="<?php echo get_field( 'register_url' ); ?>" class="bg_light_aqua"><?php echo get_field( 'Inner_register_button' ) ; ?></a>
                    </li>
                </ul>     
            </div>
        </div>
        <div class="row yc_wrapper" data-aos="fade-right">
            <div class="col-md-4 md-5">
               <div class="sc_image">
               <img src="<?php echo esc_url( get_field( 'hhi_image' ) ); ?>" alt="">
               </div>   
            </div>
            <div class="col-md-5 ps-3">
                    <div class="sc_wrapper pt-4">
                        <div class="sub_title">
                            <?php echo  get_field( 'hhi_title' ); ?>
                        </div>
                    </div>
                    <div class="regular py-3">       
                        <?php echo get_field( 'hhi_content' );?>
                    </div>
            </div>
            <div class="col-md-3 md_2 sc_flex">
               <ul class="sc_ul_serviceInfo regular text-white">
                <li class="dark_bg_aqua list_studio">
                    <?php echo get_field( 'hhi_service_info_1' ) ; ?>
                </li>
                <li class="bg_aqua list_studio">
                    <?php echo get_field( 'hhi_service_info_2' ) ; ?>
                </li>
                <li class="bg_aqua list_studio">
                    <?php echo get_field( 'hhi_service_info_3' ) ; ?>
                </li>
                <li class="bg_light_aqua list_studio">
                    <a href="<?php echo get_field( 'register_url' ); ?>" class="bg_light_aqua"><?php echo get_field( 'Inner_register_button' ) ; ?></a>
                </li>
               </ul>
            </div>
        </div>
        <div class="row yc_wrapper right_mb my-4" data-aos="fade-left">
            <div class="col-md-3 md_2 sc_flex">
                <ul class="sc_ul_serviceInfo regular text-white">

                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'day_camp_service_info_1' ) ; ?>
                    </li>
                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'day_camp_service_info_2' ) ; ?>
                    </li>
                    <li class="bg_aqua list_studio">
                        <?php echo get_field( 'day_camp_service_info_3' ) ; ?>
                    </li>
                    <li class="bg_light_aqua list_studio">
                        <a href="<?php echo get_field( 'register_url' ); ?>" class="bg_light_aqua"><?php echo get_field( 'Inner_register_button' ) ; ?></a>
                    </li>
                </ul>
            </div>
            <div class="col-md-5 ps-3">
                    <div class="sc_wrapper pt-4">
                        <div class="sub_title">
                            <?php echo  get_field( 'day_camp_title' ); ?>
                        </div>
                        <div class="description">
                            <?php echo get_field( 'day_camp_sub_title' ); ?>
                        </div>
                    </div>
                    <div class="regular py-3">       
                        <?php echo get_field( 'day_camp_content' );?>
                    </div>
            </div>
            <div class="col-md-4 md-5">
               <div class="sc_image">
               <img src="<?php echo esc_url( get_field( 'camp_image' ) ); ?>" alt="">
               </div>   
            </div>
        </div>

        <div class="row yc_wrapper mobile_yc my-4" data-aos="fade-left">
         <div class="col-md-4 md-5">
               <div class="sc_image">
               <img src="<?php echo esc_url( get_field( 'camp_image' ) ); ?>" alt="">
               </div>   
            </div>
            <div class="col-md-5 ps-3">
                    <div class="sc_wrapper pt-4">
                        <div class="sub_title">
                            <?php echo  get_field( 'day_camp_title' ); ?>
                        </div>
                        <div class="description">
                            <?php echo get_field( 'day_camp_sub_title' ); ?>
                        </div>
                    </div>
                    <div class="regular py-3">       
                        <?php echo get_field( 'day_camp_content' );?>
                    </div>
            </div>
         
            <div class="col-md-3 md_2 sc_flex">
                <ul class="sc_ul_serviceInfo regular text-white">

                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'day_camp_service_info_1' ) ; ?>
                    </li>
                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'day_camp_service_info_2' ) ; ?>
                    </li>
                    <li class="bg_aqua list_studio">
                        <?php echo get_field( 'day_camp_service_info_3' ) ; ?>
                    </li>
                    <li class="bg_light_aqua list_studio">
                        <a href="<?php echo get_field( 'register_url' ); ?>" class="bg_light_aqua"><?php echo get_field( 'Inner_register_button' ) ; ?></a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="row yc_wrapper my-4" data-aos="fade-right">
             <div class="col-md-4 md-5">
               <div class="sc_image">
                <img src="<?php echo esc_url( get_field( 'add_on_image' ) ); ?>" alt="">
               </div>   
            </div>
            <div class="col-md-5 ps-3">
                    <div class="sc_wrapper pt-4">
                        <div class="sub_title">
                            <?php echo  get_field( 'add_on_title' ); ?>
                        </div>
                    </div>
                    <div class="regular py-3">       
                        <?php echo get_field( 'add_on_content' );?>
                    </div>
            </div>
            <div class="col-md-3 md_2 sc_flex">
                <ul class="sc_ul_serviceInfo regular text-white">

                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'add_on_service_info_1' ) ; ?>
                    </li>
                    <li class="dark_bg_aqua list_studio">
                        <?php echo get_field( 'add_on_service_info_2' ) ; ?>
                    </li>
                    <li class="bg_aqua list_studio">
                        <?php echo get_field( 'add_on_service_info_3' ) ; ?>
                    </li>
                    <li class="light_aqua ">
                        <?php echo get_field( 'add_on_service_info_4' ) ; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>



<!-- Content Ends -->
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>