<?php
// Template Name: Gallery
get_header(); 
?>
<section class="Gallery page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                    <div class="page_title title">
                        <?php echo  get_field( 'gallery_title' ); ?>
                    </div>
                </div>
                <div class="regular text-center text-white">                    
                    <?php echo get_field( 'gallery_sub_title' ) ; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<section class="gallery section">
    <div class="container">
        <div class="row">
            <?php if ( have_rows( 'gallery' ) ) : ?>
                <div class="tab-container">
                    <div class="tabs">
                        <?php 
                        $tab_index = 0;
                        while ( have_rows( 'gallery' ) ) : the_row(); 
                            $tab_title = get_sub_field( 'gallery_tab_title' );
                        ?>
                            <button class="tab-link <?php echo $tab_index == 0 ? 'aqua' : ''; ?>" data-tab="tab-<?php echo $tab_index; ?>">
                                <?php echo esc_html( $tab_title ); ?>
                            </button>
                        <?php 
                            $tab_index++;
                        endwhile; 
                        ?>
                    </div>
                    <div class="tab-content">
                        <?php 
                        $tab_index = 0;
                        while ( have_rows( 'gallery' ) ) : the_row(); 
                            $images = get_sub_field( 'gallery_images' );
                        ?>
                            <div class="tab-panel <?php echo $tab_index == 0 ? 'active' : ''; ?>" id="tab-<?php echo $tab_index; ?>">
                                <div class="gallery-grid">
                                    <?php if ( $images ) : ?>
                                        <?php foreach ( $images as $image ) : 
                                            if ( is_array( $image ) && isset( $image['url'], $image['alt'] ) ) : ?>
                                                <div class="gallery-item">
                                                    <img src="<?php echo esc_url( $image['url'] ); ?>" alt="<?php echo esc_attr( $image['alt'] ); ?>" />
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    <?php else : ?>
                                        <p>No images available.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php 
                            $tab_index++;
                        endwhile; 
                        ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>  