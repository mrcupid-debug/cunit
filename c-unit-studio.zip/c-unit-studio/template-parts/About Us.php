<?php
// Template Name: About Us
get_header(); 
?>
<section class="About-US page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');"> >
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                    <?php echo get_field( 'about_title' ); ?>
                </div>
                <div class="regular text-center text-white">       
                    <?php echo get_field( 'about_description' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<section class="About pb-5">
    <div class="container">
        <div class="row py-5">
            <div class="col-md-6">
                <div class="content_wrapper pt-5">  
                    <div class="sub_title">
                    <?php echo  get_field( 'about_us_title' ) ; ?>
                    </div> 
                    <div class="regular pe-5 py-4">
                    <?php echo get_field( 'about_us_description' ); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="about_image">
                    <img src="<?php echo esc_url( get_field( 'about_us_image' ) ); ?>" alt="" style="object-fit:contain;width:100%;">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
                <div class="sub_title">        
                    <?php echo get_field( 'accordion_title' ) ; ?>
                </div> 
                <div class="regular py-3 ">           
                    <?php echo get_field( 'acoordion_description' ); ?>
                </div>
                <?php if ( have_rows( 'accordion' ) ) : ?>
                    <?php $first = true; ?>
                    <?php while ( have_rows( 'accordion' ) ) : the_row(); ?>
                    <div class="accordion <?php if ($first) echo 'active'; ?>">
                        <div class="accordion_wrapper">
                            <div class="accordion_title description">
                                <?php echo get_sub_field( 'accordion_title' ); ?>
                            </div>
                            <div class="accordion_icon">
                                <div class="dropdown_icon <?php if ($first) echo 'active'; ?>">          
                                    <?php echo get_sub_field( 'icon' ); ?>
                                </div>
                            </div>
                        </div>
                        <div class="accordion_content regular" style="<?php if ($first) { echo 'display: block;'; $first = false; } else { echo 'display: none;'; } ?>">
                            <?php echo get_sub_field( 'accordion_text' ); ?>                     
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>
            <div class="col-md-3 px-4">
                <div class="ayq_wrapper text-center">
                    <div class="ayq_title sub_title">
                        <?php echo get_field( 'ayk_title' ); ?>
                    </div>
                    <div class="ayq_form">
                        <?php if ( $form = get_field( 'form' ) ) : ?>
                            <?php echo $form; ?>
                        <?php endif; ?>
                    </div>
                    <div class="ayq_logo">
                        <img src="<?php echo  get_field( 'ask_your_question_logo' ); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  
        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>