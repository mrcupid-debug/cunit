<?php
// Template Name: Hip Hop Team
get_header(); 
?>
<section class="Hip-Hop-Team page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">
                    <?php echo get_field( 'hip_hop team_title' ); ?>
                </div>
                <div class="regular text-center text-white">         
                    <?php echo get_field( 'hip_hop team_sub_title' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<section class="hht_section section">
    <div class="container">
        <div class="row">
            <div class="col-md-6" data-aos="fade-right">
                <div class="ct--image" ><img src="<?php echo esc_url( get_field( 'what_to_expect__image' ) ); ?>" alt=""></div>
            </div>
            <div class="col-md-6 "data-aos="fade-left">
                <div class="ct_bgcolor" style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                    <div class="sub_title title pb-4">
                        <?php echo get_field( 'what_to_expect_title' ); ?>
                    </div>
                    <div class="regular__ wtec_pad">
                        <?php echo get_field( 'what_to_expect__content' ); ?>
                    </div>
                </div>
            </div>
        </div> 
        <div class="row py-3">
            <div class="col-md-6" data-aos="fade-right">
               <div class="ct_bgcolor" style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                <div class="sub_title title pb-2">
                        <?php echo get_field( 'the_groups_title' ); ?>
                    </div>
                    <div class="regular__ content_width"> 
                        <?php echo  get_field( 'the_groups_content' ); ?>
                    </div>
               </div>
            </div>
            <div class="col-md-6" data-aos="fade-left"
            data-aos-duration="300">
               <div class="ct_bgcolor" style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                    <div class="sub_title title pb-2">   
                        <?php echo get_field( 'the_requirementshours_title' ); ?>
                    </div>
                    <div class="regular__">
                        <?php echo get_field( 'the_requirementshours_content' ) ; ?>
                    </div>
               </div>
            </div>
        </div>
        
        <div class="row py-3">
            <div class="col-md-6 " data-aos="fade-right" 
            data-aos-duration="400">
               <div class="ct_bgcolor" style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                <div class="sub_title title pb-2">
                        <?php echo get_field( 'interested_in _auditioning_or_learning_more_title' ); ?>
                    </div>
                    <div class="regular__">    
                        <?php echo  get_field( 'interested_in _auditioning_or_learning_more_content' ); ?>
                    </div>
               </div>
            </div>
            <div class="col-md-6 " data-aos="fade-left"
            data-aos-duration="500" >
            <div class="center__ ct_bgcolor"  style="background-image: url('<?php echo esc_url( get_field( 'text_backdrop_image', 'options' ) ); ?>');"> 
                    <div class="color_wrapper">
                        <a class="ct_wrapper2 register_btn hover_btn" href=" <?php echo get_field( 'url', 'options' ); ?>">                    
                                <?php echo get_field( 'rgtr_button', 'options' ); ?>
                        </a>
                    </div>
               </div>
            </div>
        </div>
    </div>
</section>

<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>