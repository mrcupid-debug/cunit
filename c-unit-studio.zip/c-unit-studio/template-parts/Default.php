<?php
// Template Name: Default
get_header(); 
?>
<!-- Page Title -->
<section class="page_background_title"style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                    <div class="wrapper title"><?php echo get_field( 'page_title' ); ?></div>
                </div>
                <div class="regular text-center text-white">         
                    <?php echo get_field( 'page_sub_title' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<!-- Content Here -->





<!-- Content Ends -->
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>  