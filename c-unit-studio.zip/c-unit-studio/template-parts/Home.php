<?php
// Template Name: Home
get_header(); 
?>
<section class="hero" style="background-image: url('<?php echo esc_url( get_field( 'hero_bg_image' ) ); ?>');">  
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                    <div class="hero_content text-end">
                        <div class="hero_right_col">
                            <div class="Title">
                                <?php echo get_field( 'hero_title' ); ?>
                            </div>
                            <div class="description hero_descrip">
                              <?php echo  get_field( 'hero_sub_title' ) ; ?>
                            </div>
                        </div>
                            <a class="register_btn hover_btn hero_btn" href="<?php echo get_field( 'hero_left_link' ); ?>"> <?php echo get_field( 'hero_button_left' ); ?></a>
                    </div>
            </div>
            <div class="col-md-6">
                <div class="hero_content ">
                    <div class="hero_left_col">
                        <div class="description RobotoLight">
                            <?php echo  get_field( 'hero_sub_title_right' ); ?>
                        </div>
                    </div>
                        <div class="hero_btn_mobile">
                        <a class="register_btn hover_btn hero_btn_mobile py-2" href="<?php echo get_field( 'hero_left_link' ); ?>"> <?php echo get_field( 'hero_button_left' ); ?></a></div>
                       <div>
                       <a class="white_bg hover_btn"  data-toggle="modal" data-target="#ModalCenter" href="#"> <?php echo get_field( 'hero_button_right' ); ?></a>
                       </div>
                </div>
            </div>
        </div>
    </div>
</section>

 <!-- Modal -->
 <?php get_template_part('section/modal'); ?>


<div class="section_image_top">
        <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<section class="about_C section">
    <div class="container">
    <?php if (have_rows('repeater')) : ?>
        <?php $counter = 0; while (have_rows('repeater')) : the_row();$counter++;$row_class = ($counter % 2 != 1) ? 'row py-4 odd-child reverse-columns' : 'row py-4 even-child';?>
            <div class="<?php echo $row_class; ?>">
                <div class="col-md-6" data-aos="fade-right">
                    <div class="about_image">
                        <img src="<?php echo get_sub_field('image'); ?>" alt="" style="object-fit:contain; width: 100%;">
                    </div>
                </div>
                <div class="col-md-6" data-aos="fade-left">
                    <div class="content_wrapper pt-5">
                        <div class="sub_title">
                            <?php echo get_sub_field('sub_title'); ?>
                        </div> 
                        <div class="regular pe-5 py-4">
                            <?php echo get_sub_field('description'); ?>
                        </div>
                    </div>
                    <a href="<?php echo get_sub_field( 'link' ); ?>" class="aqua about_c_learnMore">
                        <img src="<?php echo esc_url(get_sub_field('icon')); ?>" alt="">
                        <strong class="p-2"><?php echo get_sub_field('text_link'); ?></strong>
                    </a>
                </div>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
    </div>
</section>


<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    
            <?php get_template_part('section/services'); ?>
        <?php endif; ?>  
        <?php if ( get_row_layout() == 'call_to_action' ): ?>    
            <?php get_template_part('section/cta'); ?>   
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>