jQuery(document).ready(function($) {
  var timeout;

  $('.main-menu .menu-item-has-children').hover(
    function() {
      clearTimeout(timeout);
      $(this).children('.sub-menu').stop(true, true).slideDown(500).css('opacity', 1);
    },
    function() {
      var $submenu = $(this).children('.sub-menu');
      timeout = setTimeout(function() {
        $submenu.stop(true, true).slideUp(500).css('opacity', 0);
      }, 500); // Delay for smoother transition
    }
  );
});


//   // Handle click
//   $('.menu-item-has-children > a').on('click', function(e) {
//       e.preventDefault();
//       var $submenu = $(this).siblings('.sub-menu');
//       $('.sub-menu').not($submenu).css('opacity', '0').css('transform', 'translateY(-10px)').css('pointer-events', 'none'); // Close all other submenus
//       if ($submenu.css('opacity') == '1') {
//           $submenu.css('opacity', '0').css('transform', 'translateY(-10px)').css('pointer-events', 'none');
//       } else {
//           $submenu.css('opacity', '1').css('transform', 'translateY(0)').css('pointer-events', 'auto');
//       }
//   });
// });

let mybutton = document.getElementById("myBtn");
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
mybutton.style.display = "block";
} else {
mybutton.style.display = "none";
}
}
function topFunction() {
document.body.scrollTop = 0;
document.documentElement.scrollTop = 0;
}
function sidebarMenu(x) {
x.classList.toggle("change");
document.querySelector('.Overlay_sidebar').classList.toggle('visible');
}
function mainMenu(x) {
x.classList.toggle("change");
document.querySelector('.nav_menu').classList.toggle('visible');
}
jQuery(document).ready(function($){
$('.faculty-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    dots: true,
    arrows: true,
});
});
jQuery(document).ready(function($) {
$('.tab-link').click(function() {
  var tab_id = $(this).data('tab');
  
  $('.tab-link').removeClass('aqua');
  $(this).addClass('aqua');
  
  $('.tab-panel').removeClass('active');
  $('#' + tab_id).addClass('active');
});
});
document.addEventListener('DOMContentLoaded', function () {
const tabs = document.querySelectorAll('.tab-link');
const panels = document.querySelectorAll('.tab-panel');

tabs.forEach(tab => {
  tab.addEventListener('click', function () {
      const target = this.getAttribute('data-tab');

      // Remove active class from all tabs
      tabs.forEach(t => t.classList.remove('aqua'));
      // Add active class to the clicked tab
      this.classList.add('aqua');

      // Hide all panels
      panels.forEach(panel => panel.classList.remove('active'));
      // Show the target panel
      document.getElementById(target).classList.add('active');
  });
});
});

document.addEventListener("DOMContentLoaded", function() {
document.querySelector('.download_pdf').addEventListener('click', function(event) {event.preventDefault();
  generatePDF();
});
});
function generatePDF() {
const { jsPDF } = window.jspdf;
const pdf = new jsPDF('l', 'mm', 'a4'); // Landscape orientation
const element = document.querySelector('#weeklyschedule');

html2canvas(element).then((canvas) => {
    const imgData = canvas.toDataURL('image/png');
    const imgWidth = 297; // A4 width in mm
    const pageHeight = 210; // A4 height in mm
    const imgHeight = canvas.height * imgWidth / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
    }
    pdf.save('schedule.pdf');
});
}

$(document).ready(function() {
// Log when the document is ready
console.log('Document is ready');

// Handle the modal hidden event
$('#ModalCenter').on('hidden.bs.modal', function () {
    console.log('Modal hidden event triggered');
    var video = document.getElementById('modalVideo');
    if (video) {
        video.pause();
        video.currentTime = 0;
    }
});

// Handle the custom close button click event
$('.hamburger.close.change').on('click', function() {
    console.log('Custom close button clicked');
    var video = document.getElementById('modalVideo');
    if (video) {
        video.pause();
        video.currentTime = 0;
    }
});
});

function filterContent(studio) {
// Hide all schedules
const schedules = document.querySelectorAll('.class-schedule');
schedules.forEach(schedule => schedule.classList.add('hide'));

// Show the selected schedule
if (studio === 'all') {
  schedules.forEach(schedule => schedule.classList.remove('hide'));
} else {
  document.querySelector('.' + studio).classList.remove('hide');
}
}

// Initial setup to hide all schedules
document.addEventListener('DOMContentLoaded', () => {
filterContent('all'); // Show all schedules by default
});