<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package C_Unit_Studio
 */

?>
<?php wp_footer(); ?>
<footer>
  <section class="footer section">
  <div class="container-fluid">
    <div class="row row_">
        <div class="col-md-3 p_80">
            <div class="description pb-3 ps-5">
                <?php echo get_field( 'get_in_touch', 'options' ) ; ?>
            </div>      
            <div class="content_wrapper py-3 ps-5">
                <p class="footer_text"><?php echo get_field( 'text', 'options' ); ?></p>
                <div class="contact_info pt-3">
                <?php if ( have_rows( 'contact_info', 'options' ) ) : ?>
                    <?php while ( have_rows( 'contact_info', 'options' ) ) :the_row(); ?>
                        <div class="wrapper py-3">
                            <div class="icon">
                                <?php echo get_sub_field( 'icon', 'options' ); ?>
                            </div>
                            <div class="text">
                                <?php echo  get_sub_field( 'text', 'options' ); ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-3 py-3">
            <div class="description pb-3">
                <?php echo get_field( 'latest_videos', 'options' ); ?>
            </div>
            <div class="content_wrapper pb-3">
                <div class="content_wrapper lv_wrap py-3">
                    <?php if ( have_rows( 'video_thumbnail', 'options' ) ) : ?>
                        <?php while ( have_rows( 'video_thumbnail', 'options' ) ) :the_row(); ?>
                            <div class="thumbnail py-2">
                                <a  href="<?php echo get_sub_field( 'link', 'options' ); ?>"><img src="<?php echo  get_sub_field( 'image', 'options' ); ?>" alt=""></a>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-3 py-3 right_pos">
                <div class="description">
                    <?php echo get_field( 'latest_calendar', 'options' ); ?>
                </div>
                <div class="content_wrapper pt-3">
                    <?php if ( have_rows( 'events', 'options' ) ) : ?>
                        <?php while ( have_rows( 'events', 'options' ) ) :the_row(); ?>
                            <div class="content_wrapper py-3">
                                <div class="aqua lato-13">
                                    <?php echo  get_sub_field( 'mini_date', 'options' ) ; ?>
                                </div>
                                <div class="description text font-20">
                                    <?php echo  get_sub_field( 'event_title', 'options' ); ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3 py-3">
            <div class="description pb-3">
                <?php echo get_field( 'instagram_title', 'options' ); ?>
            </div>
                <div class="content_wrapper py-3">
                    <a  class="insta_post "href="<?php echo get_field( 'instagram_link', 'options' );?>"><img src="<?php echo esc_url( get_field( 'gallery', 'options' ) ); ?>" alt=""> </a>
                </div>
            </div>
        </div>
    </div>
  </div>
  </section>
  <p class="text-center py-2 copyright_text" style="background:#2b2b2b;"><?php echo get_field( 'copyright', 'options' ); ?></p>
</footer>
</body>
</html>