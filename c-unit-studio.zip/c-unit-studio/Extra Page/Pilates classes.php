<?php
// Template Name: Pilates Classes
get_header(); 
?>
<!-- Page Title -->
<section class="Pilates_Classes page_background_title"style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');"> 
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                    <?php echo get_field( 'page_title' ); ?>
                </div>
                <div class="regular text-center text-white">         
                    <?php echo get_field( 'page_sub_title' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<!-- Content Here -->

<section class="pc_section section">
    <div class="container">
        <div class="row yc_wrapper" data-aos="fade-right">
            <div class="col-md-4 md-5">
                <div class="ex_img"> 
                    <img src="<?php echo esc_url( get_field( 'image' ) ); ?>" alt="">
               </div>
            </div>
            <div class="col-md-6">
                <div class="es_wrapper ps-3">
                    <div class="inner-wrapper">
                        <div class="es_title sub_title">             
                            <?php echo get_field( 'title' ); ?>
                        </div>
                        <div class="es_content">           
                            <?php echo  get_field( 'content' ) ; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
               <div class="a_btn_wrapper">
                    <a class="es_btn" href="<?php echo get_field( 'get_in_touch_link' ); ?>" >
                        <?php echo get_field( 'button' ); ?>
                    </a>
               </div>
            </div>
        </div>
    </div>
</section>
<section class="pc_section_instructor">
    <div class="container-fluid">
        <div class="row">
            <div class="sub_title text-center pb-5">
                <?php echo get_field( 'our_instructors_title' ); ?>
            </div>
            <?php if ( have_rows( 'of_repeater_text' ) ) :  $row_count = 0; ?>
                <?php while ( have_rows( 'of_repeater_text' ) ) : the_row(); 
                    $row_count++; 
                    $reverse = $row_count % 2 == 0; ?>
                    <div class="col-md-6<?php echo $reverse ? ' of_bgcolor text-right' : ''; ?>" data-aos="fade-right"
                    data-aos-easing="ease-in-sine">
                        <div class="<?php echo $reverse ? 'of-wrapper' : 'of_heading'; ?>">
                            <?php if ( $reverse ) : ?>
                                <div class="of_position aqua ">
                                    <?php echo get_sub_field( 'of_position' ); ?>
                                </div>  
                                <div class="of_name sub_title text-white py-2">
                                    <?php echo get_sub_field( 'of_name' ); ?>
                                </div>
                                <div class="of_about regular">
                                    <?php echo get_sub_field( 'of_about' ); ?>
                                </div>
                            <?php else : ?>
                                <div class="text_of_heading">
                                    <?php echo get_sub_field( 'of_title_text' ); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6<?php echo !$reverse ? ' of_bgcolor ' : ''; ?>" data-aos="fade-left"
                    data-aos-easing="ease-in-sine">
                        <div class="<?php echo !$reverse ? 'of-wrapper' : 'of_heading'; ?>">
                            <?php if ( !$reverse ) : ?>
                                <div class="of_position aqua regular">
                                    <?php echo get_sub_field( 'of_position' ); ?>
                                </div>  
                                <div class="of_name sub_title text-white py-2">
                                    <?php echo get_sub_field( 'of_name' ); ?>
                                </div>
                                <div class="of_about regular">
                                    <?php echo get_sub_field( 'of_about' ); ?>
                                </div>
                            <?php else : ?>
                                <div class="of_heading">
                                    <?php echo get_sub_field( 'of_title_text' ); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>      
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

    </div>
</section>

<section class="mobile_pc_instruc">
    <div class="container-fluid">
    <div class="row">
            <div class="sub_title text-center pb-5">
                <?php echo get_field( 'our_instructors_title' ); ?>
            </div>
            <?php if ( have_rows( 'of_repeater_text' ) ) : ?>
                <?php while ( have_rows( 'of_repeater_text' ) ) : the_row(); ?>
                    <div class="col-md-6"data-aos="fade-right"
                    data-aos-easing="ease-in-sine" >
                        <div class="of_heading">
                                <div class="text_of_heading">
                                    <?php echo get_sub_field( 'of_title_text' ); ?>
                                </div>
                        </div>
                    </div>
                    <div class="col-md-6 of_bgcolor"data-aos="fade-left"data-aos-easing="ease-in-sine">
                        <div class="of-wrapper">
                            <div class="of_position aqua regular">
                                <?php echo get_sub_field( 'of_position' ); ?>
                            </div>  
                            <div class="of_name sub_title text-white py-2">
                                <?php echo get_sub_field( 'of_name' ); ?>
                            </div>
                            <div class="of_about regular">
                                <?php echo get_sub_field( 'of_about' ); ?>
                            </div>
                        </div>
                    </div>      
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Content Ends -->
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>  