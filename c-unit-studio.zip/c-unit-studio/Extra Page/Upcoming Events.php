<?php
// Template Name: Upcoming Events
get_header(); 
?>
<!-- Page Title -->
<section class="Upcoming_Event page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');"> 
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                   <?php echo get_field( 'page_title' ); ?>
                </div>
                <div class="regular text-center text-white">         
                    <?php echo get_field( 'page_sub_title' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<!-- Content Here -->
 
<section class="ue_event section">
    <div class="container">
        <div class="row yc_wrapper" data-aos="fade-right">
            <div class="col-md-4 md-5">
                <div class="ex_img"> 
                    <img src="<?php echo esc_url( get_field( 'image' ) ); ?>" alt="">
               </div>
            </div>
            <div class="col-md-6">
                <div class="es_wrapper ps-3">
                    <div class="inner-wrapper">
                        <div class="es_title sub_title">             
                            <?php echo get_field( 'title' ); ?>
                        </div>
                        <div class="es_content regular">           
                            <?php echo  get_field( 'content' ) ; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
               <div class="es_btn_wrapper">
                    <div class="es_wrap_wrapper">
                        <ul class="ue_event_wrapper">
                            <li class="get_in_T">
                                <a class="es_btn" href="<?php echo get_field( 'get_in_touch_link' ); ?>" >
                                    <?php echo get_field( 'button_1' ); ?>
                                </a>
                            </li>
                            <li class="get_in_T pt-1">
                                <a class="yc_btn" href="<?php echo get_field( 'view_callendar_link' ); ?>" >
                                    <?php echo get_field( 'button_2' ); ?>
                                </a >
                            </li>
                        </ul>
                    </div>
               </div>
            </div>
        </div>
    </div>
</section>

<!-- Content Ends -->
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>  