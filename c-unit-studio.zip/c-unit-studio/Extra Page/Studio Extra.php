<?php
// Template Name: Studio Extra
get_header(); 
?>
<!-- Page Title -->
<section class="Studio_extra page_background_title" style="background-image: url('<?php echo esc_url( get_field( 'header_section_image', 'options' ) ); ?>');"> 
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page_title text-white">     
                    <?php echo get_field( 'page_title' ); ?>
                </div>
                <div class="regular text-center text-white">         
                    <?php echo get_field( 'page_sub_title' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_image_top">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<!-- Content Here -->
<section class="extra_section section">
    <div class="container">
        <div class="row yc_wrapper" data-aos="fade-right">
            <div class="col-md-4 md-5">
                <div class="ex_img"> 
                    <img src="<?php echo esc_url( get_field( 'birthday_parties_image' ) ); ?>" alt="">
               </div>
            </div>
            <div class="col-md-6">
                <div class="es_wrapper ps-3">
                    <div class="inner-wrapper">
                        <div class="es_title sub_title">             
                            <?php echo get_field( 'title' ); ?>
                        </div>
                        <div class="es_content">           
                            <?php echo  get_field( 'birthday_parties_content' ) ; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
               <div class="a_btn_wrapper">
                    <a class="es_btn" href="<?php echo get_field( 'btn_link' ); ?>" >
                        <?php echo get_field( 'extra_button' ); ?>
                    </a>
               </div>
            </div>
        </div>

        <div class="row yc_wrapper right_mb my-4" data-aos="fade-left">
            <div class="col-md-2">
                <div class="a_btn_wrapper">
                        <a class="es_btn" href="<?php echo get_field( 'btn_link' ); ?>" >
                            <?php echo get_field( 'extra_button' ); ?>
                        </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="es_wrapper ps-3">
                    <div class="inner-wrapper">
                        <div class="es_title sub_title">             
                            <?php echo get_field( 'event_choreography_title' ); ?>
                        </div>
                        <div class="es_content regular">           
                            <?php echo  get_field( 'event_choreography_content' ) ; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 md-5">
                <div class="ex_img"> 
                    <img src="<?php echo esc_url( get_field( 'event_choreography_image' ) ); ?>" alt="">
               </div>
            </div>
        </div>

        <div class="row yc_wrapper mobile_yc my-4" data-aos="fade-left">
            <div class="col-md-4 md-5">
                <div class="ex_img"> 
                    <img src="<?php echo esc_url( get_field( 'event_choreography_image' ) ); ?>" alt="">
               </div>
            </div>
            <div class="col-md-6">
                <div class="es_wrapper ps-3">
                    <div class="inner-wrapper">
                        <div class="es_title sub_title">             
                            <?php echo get_field( 'event_choreography_title' ); ?>
                        </div>
                        <div class="es_content regular">           
                            <?php echo  get_field( 'event_choreography_content' ) ; ?>
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="col-md-2">
                <div class="a_btn_wrapper">
                        <a class="es_btn" href="<?php echo get_field( 'btn_link' ); ?>" >
                            <?php echo get_field( 'extra_button' ); ?>
                        </a>
                </div>
            </div>
        </div>

    </div>
</section>




<!-- Content Ends -->
<?php if ( have_rows('flexible-content', 'options') ) : ?>
    <?php while ( have_rows('flexible-content', 'options') ) : the_row(); ?>

        <?php if ( get_row_layout() == 'services' ): ?>    

            <?php get_template_part('section/services'); ?>

        <?php endif; ?>  

        <?php if ( get_row_layout() == 'call_to_action' ): ?>    

            <?php get_template_part('section/cta'); ?>
            
        <?php endif; ?>  

    <?php endwhile; ?>
<?php endif; ?>
<?php
get_footer(); 
?>  