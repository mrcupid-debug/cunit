<div class="section_image_bottom">
    <img src="<?php echo esc_url( get_field( 'section_image', 'options' ) ); ?>" alt="">
</div>
<section class="section services_block section">
   
    <div class="container">
        <div class="row">
            <div class="col-lg-4 pb-3">
                <div class="svc_img">
                    <div class="svc_img_wrap"><img src="<?php echo esc_url( get_sub_field( 'fall_registration_image', 'options' ) ); ?>" alt="">
                        <a href="<?php echo get_sub_field( 'fall_registration_url', 'options' ); ?>" class="bottom-right register_btn" data-aos="fade-up-left">
                            <?php echo get_sub_field( 'fg_button_text', 'options' ); ?></a>
                        </a>    
                    </div>
                </div>  
                <div class="svc_wrapper">   
                    <div class="fall-reg-title sub_title  py-2">
                        <?php echo get_sub_field( 'fall_registration_title', 'options' ); ?>
                    </div>
                    <div class="regular service_regular pe-4">
                        <?php echo get_sub_field( 'fall_registration_description', 'options' ); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 pb-3">
            <div class="svc_img">
                    <div class="svc_img_wrap"><img src="<?php echo esc_url( get_sub_field( 'competitive_dance_image', 'options' ) ); ?>" alt="">
                        <a href="<?php echo get_sub_field( 'competitive_dance_button_1_url', 'options' ); ?>" class="bottom-left register_btn" data-aos="fade-down-right">
                            <?php echo get_sub_field( 'competitive_dance_button_text_1', 'options' ); ?></a>
                        <a href="<?php echo get_sub_field( 'competitive_dance_button_2_url_', 'options' ); ?>" class="top-right register_btn" data-aos="fade-down-left">
                            <?php echo get_sub_field( 'competitive_dance_button_text_2', 'options' ); ?>
                        </a>
                    </div>
                </div>
                <div class="svc_wrapper">   
                    <div class="fall-reg-title sub_title  py-2">             
                        <?php echo get_sub_field( 'competitive_dance_title', 'options' ); ?>
                    </div>
                    <div class="regular service_regular pe-4">
                        <?php echo get_sub_field( 'competitive_dance_text', 'options' ); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 pb-3">
                <div class="svc_img">
                    <div class="svc_img_wrap"><img src="<?php echo esc_url( get_sub_field( 'summer_camp_image', 'options' ) ); ?>" alt="">
                        <a href="<?php echo get_sub_field( 'summer_camp_button_url', 'options' ); ?>" class="bottom-right register_btn" data-aos="fade-up-left">
                        <?php echo get_sub_field( 'sc_button_text', 'options' ); ?></a>
                    </div>
                </div>
                <div class="svc_wrapper">   
                    <div class="fall-reg-title sub_title  py-2">
                        <?php echo get_sub_field( 'summer_camp_title', 'options' ); ?>
                    </div>
                    <div class="regular service_regular pe-4">               
                        <?php echo get_sub_field( 'summer_camp_text', 'options' ); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>