<div class="section_modal modal fade" id="ModalCenter" tabindex="-1" role="dialog" aria-labelledby="ModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="hamburger close change" data-dismiss="modal" aria-label="Close">
                    <div class="span1"></div>
                    <div class="span2"></div>
                    <div class="span3"></div>
                </div> 
            </div>
            <div class="modal-body">
                <video id="modalVideo" controls style="width: 100%;">
                    <source src="<?php echo get_field( 'mp4', 'options' ); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>
        </div>
    </div>
</div>