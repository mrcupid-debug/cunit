<section class="cta_block" style="background-image: url('<?php echo esc_url( get_sub_field( 'cta_image', 'options' ) ); ?> ');">  
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="cta_title">
                    <?php echo get_sub_field( 'cta_title', 'options' ); ?>
                </div>
                <div class="cta_description regular text-white py-4">
                <?php echo get_sub_field( 'cta_description', 'options' ); ?>
                </div>
                <div class="cta_btn white_bg hover_btn">
                <a href="<?php echo get_sub_field( 'cta_url', 'options' ) ; ?>" class="white_bg hover_btn"> <?php echo get_sub_field( 'cta_button', 'options' ); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>


